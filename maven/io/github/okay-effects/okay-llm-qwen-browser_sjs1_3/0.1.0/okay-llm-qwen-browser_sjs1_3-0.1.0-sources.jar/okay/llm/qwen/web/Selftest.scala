package okay.llm.qwen.web

import okay.effects.json.Json
import okay.llm.compute.{Compute, OnCpu, OnWebGl2, OnWebGpu}
import okay.llm.qwen.{Qwen3Compute, Qwen3Config, Safetensors, Tokenizer}

import scala.concurrent.Future
import scala.scalajs.concurrent.JSExecutionContext.Implicits.queue
import scala.scalajs.js
import scala.scalajs.js.Dynamic.global as g
import scala.scalajs.js.typedarray.*

/**
 * THE PAGE'S SELF-TEST (browser/index.html, `?model=<dir url>`): the model's files fetched (config.json,
 * tokenizer.json, model.safetensors), a prompt tokenized in the page, the forward on WebGPU and on WebGL2 against
 * the CPU handler in the same page — the states after the last layer at the first and the last position, the
 * logits, the next token — the largest difference and the time of each, written into the page (#selftest).
 */
object Selftest:
  def main(args: Array[String]): Unit =
    val out = g.document.createElement("pre"); out.id = "selftest"
    g.document.body.appendChild(out)
    def say(s: String): Unit = { out.textContent = out.textContent.toString + s + "\n"; println(s) }
    val now = () => g.performance.now().asInstanceOf[Double]
    val params = js.Dynamic.newInstance(g.URLSearchParams)(g.location.search)
    val dir = Option(params.get("model").asInstanceOf[String]).getOrElse("model")
    def fetch(name: String): Future[ArrayBuffer] =
      g.fetch(s"$dir/$name").asInstanceOf[js.Promise[js.Dynamic]].toFuture.flatMap { r =>
        if !r.ok.asInstanceOf[Boolean] then Future.failed(IllegalStateException(s"$name: HTTP ${r.status}"))
        else r.arrayBuffer().asInstanceOf[js.Promise[ArrayBuffer]].toFuture
      }
    def text(ab: ArrayBuffer): String = js.Dynamic.newInstance(g.TextDecoder)().decode(ab).asInstanceOf[String]
    (for
      configText <- fetch("config.json").map(text)
      tokText <- fetch("tokenizer.json").map(text)
      model <- fetch("model.safetensors")
      config = Qwen3Config.parse(configText)
      tok = Tokenizer.fromJson(Json.fromText(tokText))
      st = new Safetensors(TypedArrayBuffer.wrap(model))
      prompt = "<|im_start|>user\nHow many rows have country = France?<|im_end|>\n<|im_start|>assistant\n"
      ids = tok.encode(prompt)
      _ = say(s"model: ${config.layers} layers, ${model.byteLength / 1048576} MB; the prompt ${ids.length} tokens: " +
        ids.mkString(" "))
      at = Seq(0, ids.length - 1)
      run = (c: Compute) =>
        val t0 = now(); val m = Qwen3Compute(c, st, config); val t1 = now()
        m.forward(ids, config.layers, at, withLogits = true).flatMap { case (states, logits) =>
          val t2 = now()
          val next = logits.indexOf(logits.max)
          say(f"${c.api}: weights up ${(t1 - t0) / 1000}%.1f s, forward ${(t2 - t1) / 1000}%.1f s; next token $next " +
            s"'${tok.decode(Seq(next))}'")
          // THE CACHE'S LAW on this device: the first 12 tokens run and kept, the rest after them — the same states
          // and logits as the whole at once
          (for
            (_, _, cache) <- m.run(ids.take(12), config.layers, Nil, withLogits = false, None, keep = true)
            (s2, l2, _) <- m.run(ids, config.layers, at, withLogits = true, cache, keep = false)
          yield
            val sd = states.zip(s2).map((a, b) => a.zip(b).map((x, y) => math.abs(x - y)).max)
            val ld = logits.zip(l2).map((x, y) => math.abs(x - y)).max
            say(f"${c.api} cache vs whole: states' max abs diff ${sd.mkString(" ")}; logits' $ld%.4f; " +
              s"next ${if l2.indexOf(l2.max) == next then "the same" else "DIFFERENT"}")
            cache.foreach(_.free())
            if !(sd.forall(_ < 0.05f) && ld < 0.1f) then throw IllegalStateException(s"${c.api}: the cache differs")
            (states, logits, next))
        }
      cpu <- run(OnCpu())
      check = (name: String, got: (Vector[Array[Float]], Array[Float], Int)) =>
        val sd = cpu._1.zip(got._1).map((a, b) => a.zip(b).map((x, y) => math.abs(x - y)).max)
        val ld = cpu._2.zip(got._2).map((x, y) => math.abs(x - y)).max
        val scale = cpu._1.map(_.map(math.abs).max).max
        say(f"$name vs CPU: states' max abs diff ${sd.mkString(" ")} (the states' max $scale%.0f); logits' $ld%.3f; " +
          s"next token ${if got._3 == cpu._3 then "the same" else "DIFFERENT"}")
        sd.forall(_ < 0.02f * scale + 0.05f) && ld < 0.5f && got._3 == cpu._3
      // THE OPTIONS WEIGHED PACKED on a device (one forward, the log-probabilities on the device) against the CPU's
      weigh = (c: Compute) =>
        val m = Qwen3Compute(c, st, config)
        val options = Vector(ids.slice(3, 5), ids.slice(5, 6), ids.slice(6, 10))
        m.run(ids.init, config.layers, Nil, withLogits = false, None, keep = true).flatMap { (_, _, cache) =>
          val t0 = now()
          m.score(cache.get, ids.last, options).map { s => cache.foreach(_.free()); (s, now() - t0) } }
      cpuWeighed <- weigh(OnCpu())
      weighs = (name: String, got: (Vector[Double], Double)) =>
        val d = got._1.zip(cpuWeighed._1).map((a, b) => math.abs(a - b)).max
        val said = got._1.map(x => f"$x%.3f").mkString(" ")
        say(f"$name packed weighing: $said in ${got._2}%.0f ms; vs CPU max diff $d%.4f")
        d < 0.1
      gpu <- OnWebGpu.create()
      okGpu <- gpu.fold(why => { say(s"WebGPU: $why"); Future.successful(true) },
        d => { say(s"WebGPU: ${d.adapter}"); run(d).map(check("WebGPU", _)).flatMap(ok =>
          weigh(d).map(w => ok && weighs("WebGPU", w))) })
      gl = OnWebGl2.create(headsAtOnce = 2)
      okGl <- gl.fold(why => { say(s"WebGL2: $why"); Future.successful(true) },
        d => { say(s"WebGL2: ${d.adapter}"); run(d).map(check("WebGL2", _)).flatMap(ok =>
          weigh(d).map(w => ok && weighs("WebGL2", w))) })
    yield say(if okGpu && okGl then "selftest: done" else "selftest: failed: a device differs from the CPU"))
      .recover { case e => say(s"selftest: failed: $e"); e.printStackTrace() }
