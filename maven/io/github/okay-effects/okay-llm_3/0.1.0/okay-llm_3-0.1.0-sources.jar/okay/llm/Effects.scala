package okay.llm

import okay.effects.json.Json

import java.nio.file.{Files as NioFiles, Path}
import scala.collection.mutable
import okay.scala3.*

/** what is asked of a model: a conversation (messages as a chat template takes them: role, content, tool calls), the
 * tools it may call, how many tokens at most, whether it thinks first; how tokens are drawn — each unset, the
 * model's own (a backend's default); the model the request names, if any (a backend of several picks by it) */
final case class Ask(messages: Vector[Json], tools: Vector[Json] = Vector.empty, maxTokens: Int = 1024,
    thinking: Boolean = false, sampling: Sampling = Sampling(), model: Option[String] = None)

/** HOW TOKENS ARE DRAWN, as a request says: temperature (0: greedy), top_p, top_k, a seed, OpenAI's presence and
 * frequency penalties (against a loop); each unset, the backend's */
final case class Sampling(temperature: Option[Double] = None, topP: Option[Double] = None, topK: Option[Int] = None,
    seed: Option[Long] = None, presencePenalty: Option[Double] = None, frequencyPenalty: Option[Double] = None)

object Sampling:
  /** a request's fields: `temperature`, `top_p`, `top_k`, `seed`, `presence_penalty`, `frequency_penalty` */
  def of(body: Json): Sampling =
    Sampling(body.field("temperature").map(_.double), body.field("top_p").map(_.double),
      body.field("top_k").map(_.int), body.field("seed").map(_.long), body.field("presence_penalty").map(_.double),
      body.field("frequency_penalty").map(_.double))

object Ask:
  /** a system message where a chat template takes none — after the first message (Claude Code sends one each turn,
   * mid-conversation; Qwen3.6's template raises) — as a user message, where it is. Not moved to the first: the
   * prompt's beginning stays the same from turn to turn, and a cache of prefixes keeps it */
  def systemFirst(messages: Vector[Json]): Vector[Json] =
    messages.zipWithIndex.map { (m, i) =>
      if i > 0 && m("role") == Json.Str("system") then
        Json.Obj(m.record.map((k, v) => if k == "role" then k -> Json.Str("user") else k -> v))
      else m
    }

/** a generation going on */
final case class Gen(id: Long)

/** what a generation measured: the prompt's tokens and the time to the first new one (the prefill), the tokens made
 * and their time after the first (the decode); how many of the prompt's a cache of prefixes gave */
final case class Timing(promptTokens: Int, prefillNanos: Long, tokens: Int, decodeNanos: Long, cachedTokens: Int = 0):
  /** the prompt's tokens computed a second — not those a cache of prefixes gave */
  def prefillPerSecond: Double = (promptTokens - cachedTokens) / (prefillNanos / 1e9)
  def decodePerSecond: Double = if tokens <= 1 then 0 else (tokens - 1) / (decodeNanos / 1e9)

/** a generation done: its turn read, what it measured, whether the model ended it (else: the limit) */
final case class Finished(reply: Reply, timing: Timing, byStop: Boolean)

/** THE LANGUAGE MODEL, as a program sees it: its name, a prompt's size, a generation started, its text piece by
 * piece, its end. Which model, on which hardware, is the handler's — a module of its own (okay-mlx: Apple's MLX) */
enum Llm[X]:
  case Name() extends Llm[String]
  case Models() extends Llm[Vector[String]]
  case Count(ask: Ask) extends Llm[Int]
  case Start(ask: Ask) extends Llm[Gen]
  case Next(gen: Gen) extends Llm[Option[String]]
  case Finish(gen: Gen) extends Llm[Finished]

object Llm:
  def name[R[_]](using In[Llm, R]): String ! R = perform[Llm](Name())
  /** the models it may answer by, the one it has now first */
  def models[R[_]](using In[Llm, R]): Vector[String] ! R = perform[Llm](Models())
  def count[R[_]](ask: Ask)(using In[Llm, R]): Int ! R = perform[Llm](Count(ask))
  def start[R[_]](ask: Ask)(using In[Llm, R]): Gen ! R = perform[Llm](Start(ask))
  /** the next piece of text, or none: the generation is over */
  def next[R[_]](gen: Gen)(using In[Llm, R]): Option[String] ! R = perform[Llm](Next(gen))
  def finish[R[_]](gen: Gen)(using In[Llm, R]): Finished ! R = perform[Llm](Finish(gen))

  /** a generation to its end */
  def complete[R[_]](ask: Ask)(using In[Llm, R]): Finished ! R =
    for
      g <- start(ask)
      _ <- loop[Unit, Unit, R](())(_ => next(g).map(p => if p.isDefined then Left(()) else Right(())))
      f <- finish(g)
    yield f

  /** A MODEL OF YOUR OWN: what a hardware module implements — a prompt's size, a generation as an iterator of text
   * pieces — and the handler made of it */
  trait Backend:
    def name: String
    /** the models it may answer by, `name` first: a backend of one, that one */
    def models: Vector[String] = Vector(name)
    def count(ask: Ask): Int
    def start(ask: Ask): Generation
  /** a generation going on: its pieces; at its end, its whole text and what it measured */
  trait Generation:
    def next(): Option[String]
    def text: String
    def timing: Timing
    def byStop: Boolean
    def close(): Unit
    /** the turn read: from the text (a model's own, here), or as a server read it already (`HttpBackend`) */
    def reply(thinking: Boolean, tools: Seq[Json]): Reply = Reply.parse(text, thinking, tools)

  def on[R[_], Rest[_], A](backend: Backend)(p: A ! R)(using Split[Llm, R, Rest]): A ! Rest =
    val running = mutable.HashMap.empty[Long, (Generation, Ask)]
    var ids = 0L
    handle(p, Handler.tail[Llm, Rest, A, A](pure)([X] => (op: Llm[X]) => op match
      case Name() => backend.name
      case Models() => backend.models
      case Count(ask) => backend.count(ask)
      case Start(ask) =>
        ids += 1
        running(ids) = (backend.start(ask), ask)
        Gen(ids)
      case Next(gen) => running(gen.id)._1.next()
      case Finish(gen) =>
        val (g, ask) = running.remove(gen.id).get
        g.close()
        Finished(g.reply(ask.thinking, ask.tools), g.timing, g.byStop)))

  /** answers given by a function of the last message's text, piece by piece (by word), timings made up: the
   * programs without a model */
  def fake[R[_], Rest[_], A](answer: String => String)(p: A ! R)(using Split[Llm, R, Rest]): A ! Rest =
    on(Fake(answer))(p)

  private final class Fake(answer: String => String) extends Backend:
    def name = "fake"
    private def lastText(ask: Ask) =
      ask.messages.lastOption.map(_("content")).collect { case Json.Str(s) => s }.getOrElse("")
    def count(ask: Ask) =
      ask.messages.map(m => m("content") match { case Json.Str(s) => s.length / 4 + 4; case _ => 4 }).sum
    def start(ask: Ask) = new Generation:
      private var rest = words(answer(lastText(ask)))
      private val sb = new StringBuilder
      def next() = rest match
        case piece :: more => rest = more; sb.append(piece); Some(piece)
        case Nil => None
      def text = sb.toString
      def timing =
        val n = sb.length / 4 + 1
        Timing(10, 1_000_000L, n, n * 10_000_000L)
      def byStop = true
      def close() = ()
    /** the text in pieces a word each, its space kept after it (no look-behind: Scala Native's regex is RE2's) */
    private def words(s: String): List[String] =
      val out = List.newBuilder[String]
      var from = 0
      for i <- s.indices if s.charAt(i) == ' ' do { out += s.substring(from, i + 1); from = i + 1 }
      if from < s.length then out += s.substring(from)
      out.result()

/** FILES: a text read */
enum Files[X]:
  case Read(path: Path) extends Files[String]

object Files:
  def read[R[_]](path: Path)(using In[Files, R]): String ! R = perform[Files](Read(path))

  def disk[R[_], Rest[_], A](p: A ! R)(using Split[Files, R, Rest]): A ! Rest =
    handle(p, Handler.tail[Files, Rest, A, A](pure)([X] => (op: Files[X]) => op match
      case Read(path) => NioFiles.readString(path)))

  /** files given: a map of paths to texts */
  def of[R[_], Rest[_], A](files: Map[Path, String])(p: A ! R)(using Split[Files, R, Rest]): A ! Rest =
    handle(p, Handler.tail[Files, Rest, A, A](pure)([X] => (op: Files[X]) => op match
      case Read(path) => files.getOrElse(path, throw java.io.FileNotFoundException(path.toString))))

/** THE CONSOLE: a line out */
enum Console[X]:
  case Line(text: String) extends Console[Unit]

object Console:
  def line[R[_]](text: String)(using In[Console, R]): Unit ! R = perform[Console](Line(text))

  def stdout[R[_], Rest[_], A](p: A ! R)(using Split[Console, R, Rest]): A ! Rest =
    handle(p, Handler.tail[Console, Rest, A, A](pure)([X] => (op: Console[X]) => op match
      case Line(text) => println(text)))

  /** the lines, in order, and the value */
  def collect[R[_], Rest[_], A](p: A ! R)(using Split[Console, R, Rest]): (Vector[String], A) ! Rest =
    handle(p, Handler.stateful[Console, Rest, A, (Vector[String], A), Vector[String]](Vector.empty)(
      (lines, a) => pure((lines, a)))(
      [X] => (op: Console[X], cell: Cell[Vector[String]]) => op match
        case Line(text) => cell.set(cell.get :+ text)))

/** AN HTTP REQUEST, read */
final case class Request(method: String, path: String, headers: Map[String, String], body: String)

/** AN HTTP RESPONSE, as the program makes it: whole, or streamed — opened, sent piece by piece, closed */
enum Http[X]:
  case Respond(status: Int, contentType: String, body: String) extends Http[Unit]
  case Open(status: Int, contentType: String) extends Http[Unit]
  case Send(chunk: String) extends Http[Unit]
  case Close() extends Http[Unit]

object Http:
  def respond[R[_]](status: Int, contentType: String, body: String)(using In[Http, R]): Unit ! R =
    perform[Http](Respond(status, contentType, body))
  def json[R[_]](status: Int, body: Json)(using In[Http, R]): Unit ! R =
    respond(status, "application/json", body.render)
  def open[R[_]](status: Int, contentType: String)(using In[Http, R]): Unit ! R =
    perform[Http](Open(status, contentType))
  def send[R[_]](chunk: String)(using In[Http, R]): Unit ! R = perform[Http](Send(chunk))
  def close[R[_]](using In[Http, R]): Unit ! R = perform[Http](Close())

  private def reason(status: Int) = status match
    case 200 => "OK"; case 400 => "Bad Request"; case 404 => "Not Found"; case 500 => "Internal Server Error"
    case _ => "Status"

  /** to a socket's stream: a whole response with its length; a streamed one closed by closing the connection */
  def socket[R[_], Rest[_], A](out: java.io.OutputStream)(p: A ! R)(using Split[Http, R, Rest]): A ! Rest =
    def head(status: Int, contentType: String, extra: String) =
      out.write((s"HTTP/1.1 $status ${reason(status)}\r\nContent-Type: $contentType\r\n$extra" +
        "Connection: close\r\n\r\n").getBytes("UTF-8"))
    handle(p, Handler.tail[Http, Rest, A, A](pure)([X] => (op: Http[X]) => op match
      case Respond(status, contentType, body) =>
        val bytes = body.getBytes("UTF-8")
        head(status, contentType, s"Content-Length: ${bytes.length}\r\n")
        out.write(bytes)
        out.flush()
      case Open(status, contentType) =>
        head(status, contentType, "Cache-Control: no-cache\r\n")
        out.flush()
      case Send(chunk) =>
        out.write(chunk.getBytes("UTF-8"))
        out.flush()
      case Close() => out.flush()))

  /** what was sent: the status, the content type, the body (pieces joined) */
  def collect[R[_], Rest[_], A](p: A ! R)(using Split[Http, R, Rest]): ((Int, String, String), A) ! Rest =
    handle(p, Handler.stateful[Http, Rest, A, ((Int, String, String), A), (Int, String, String)]((0, "", ""))(
      (r, a) => pure((r, a)))(
      [X] => (op: Http[X], cell: Cell[(Int, String, String)]) => op match
        case Respond(status, contentType, body) => cell.set((status, contentType, body))
        case Open(status, contentType) => cell.set((status, contentType, ""))
        case Send(chunk) => val (s, c, b) = cell.get; cell.set((s, c, b + chunk))
        case Close() => ()))
