package okay.llm.qwen

import okay.llm.compute.Compute

import scala.concurrent.{ExecutionContext, Future}

/**
 * QWEN3'S FORWARD AS A PROGRAM OVER `Compute`: the one forward (the plain-Scala `Qwen3Forward` it once mirrored is gone; `OnCpu` is the reference, `OnMlx` the independent check) — as `Qwen3Forward` — the embedding gathered on the CPU
 * (one row a token), then for each layer the norm, q k v, the heads normed and rotated, attention, the output
 * projection and the residual, the norm, gate and up, SwiGLU, down and the residual; the final norm; the logits of
 * the last row against the tied head. The weights go to the device once, at construction. What a skill needs: the
 * residual after a layer at some positions (`layer`, `at`), and the next token's logits.
 */
/** `headOnCpu`: the logits against the tied head computed on the CPU from the last row read back, the embedding's
 * 78 MB not sent to the device — a phone's WebGL2 has no room for it; slower an ask (150M multiplies in JS) */
/** `embed`: the embedding's rows — the whole from the file, or blocks by language (`Rows.Blocks`, more loaded as tokens
 * appear: `rehead()` after) */
final class Qwen3Compute(val c: Compute, st: Tensors, val config: Qwen3Config, headOnCpu: Boolean = false,
    embedGiven: Option[Rows] = None):
  import config.*
  /** a layer's weights on the device; a component the file has not (removed by the map: okay-inlay specs/core.md §11)
   * is None and the forward skips it — the residual goes on as it was */
  final case class Attn(inNorm: c.T, q: c.W, k: c.W, v: c.W, o: c.W, qNorm: c.T, kNorm: c.T)
  final case class Mlp(postNorm: c.T, gate: c.W, up: c.W, down: c.W)
  final case class Layer(attn: Option[Attn], mlp: Option[Mlp])
  // THE FILE IS READ ONCE, HERE, AND NOT KEPT: the weights live on the device from now on (a phone's browser has no
  // room for the file beside them — 244 MB held by this object was a tab killed); the embedding stays on the CPU
  // for the gather
  val (blocks: Vector[Layer], embedding: Rows) =
    def lin(p: String): c.W = c.quantized(st.linear(p))
    def vec(name: String): c.T = { val a = st.floats(name); c.tensor(1, a.length, a) }
    val layersRead = Vector.tabulate(layers) { i =>
      val p = s"model.layers.$i."
      Layer(
        Option.when(st.has(p + "self_attn.o_proj.weight"))(Attn(vec(p + "input_layernorm.weight"),
          lin(p + "self_attn.q_proj"), lin(p + "self_attn.k_proj"), lin(p + "self_attn.v_proj"), lin(p + "self_attn.o_proj"),
          vec(p + "self_attn.q_norm.weight"), vec(p + "self_attn.k_norm.weight"))),
        Option.when(st.has(p + "mlp.down_proj.weight"))(Mlp(vec(p + "post_attention_layernorm.weight"),
          lin(p + "mlp.gate_proj"), lin(p + "mlp.up_proj"), lin(p + "mlp.down_proj"))))
    }
    (layersRead, embedGiven.getOrElse(Rows.Full(st.linear("model.embed_tokens"))))
  // the head: the loaded rows on the device, and the id of each; made again when rows are added
  private var head: Option[(c.W, Array[Int])] = None
  // THE HEAD THE FILE HAS: its own `lm_head` (untied), else the embedding's rows (tied)
  private val untied: Option[okay.llm.compute.QLinear] = Option.when(st.has("lm_head.weight"))(st.linear("lm_head"))
  def rehead(): Unit = if !headOnCpu then
    head = Some(untied.fold { val (q, ids) = embedding.packed; (c.quantized(q), ids) }(u => (c.quantized(u), Array.tabulate(u.out)(identity))))
  rehead()
  private val norm: c.T = { val a = st.floats("model.norm.weight"); c.tensor(1, a.length, a) }

  /** A PREFIX ALREADY RUN: its length, every layer's k and v on the device (the rows 0 until n), the residual after
   * `layer` for those rows — so a sequence that begins with it runs only the rest. Freed by `free` */
  final class Cache(val n: Int, val k: Vector[c.T], val v: Vector[c.T], val h: c.T, val layer: Int):
    private val released = Array.fill(k.size)(false)
    private var statesReleased = false
    private var consumed = false
    private[Qwen3Compute] def requireLive(): Unit = require(!consumed, "the prefix cache was consumed or freed")
    private[Qwen3Compute] def consume(): Unit = { requireLive(); consumed = true }
    private[Qwen3Compute] def freeLayer(i: Int): Unit = if !released(i) then
      released(i) = true
      c.release(k(i)); c.release(v(i))
    private[Qwen3Compute] def freeStates(): Unit = if !statesReleased then
      statesReleased = true
      c.release(h)
    def free(): Unit =
      consumed = true
      k.indices.foreach(freeLayer)
      freeStates()

  /** the residual after `layer` at the rows `at` (none when `layer` is 0), and the next token's logits if asked */
  def forward(ids: Array[Int], layer: Int, at: Seq[Int], withLogits: Boolean)(using ExecutionContext)
      : Future[(Vector[Array[Float]], Array[Float])] =
    run(ids, layer, at, withLogits, None, keep = false).map((s, l, _) => (s, l))

  /** the same, after a cached prefix (`ids` begins with it: only the rest is run), and — `keep` — the whole of `ids`
   * cached for the next call; a cache given and not kept stays as it was */
  def run(ids: Array[Int], layer: Int, at: Seq[Int], withLogits: Boolean, cache: Option[Cache], keep: Boolean)(
      using ExecutionContext): Future[(Vector[Array[Float]], Array[Float], Option[Cache])] =
    run(ids, layer, at, withLogits, cache, keep, consumeCache = false)

  /** A decoder can transfer ownership of its old prefix; release each layer after its keys/values were copied.
    * Other callers retain the reusable-cache contract of the six-argument overload.
    */
  def run(ids: Array[Int], layer: Int, at: Seq[Int], withLogits: Boolean, cache: Option[Cache], keep: Boolean,
      consumeCache: Boolean)(using ExecutionContext): Future[(Vector[Array[Float]], Array[Float], Option[Cache])] =
    cache.foreach(_.requireLive())
    require(!consumeCache || (cache.nonEmpty && keep), "consuming a cache requires a retained successor")
    val n0 = cache.fold(0)(_.n)
    require(n0 <= ids.length, "the cached prefix is longer than the sequence")
    require(cache.forall(_.layer == layer) || at.forall(_ >= n0), "the cache holds another layer's states")
    val suffix = ids.drop(n0); val n = suffix.length
    val (before, after) = at.partition(_ < n0)
    val fromCache: Future[Vector[Array[Float]]] =
      if before.isEmpty then Future.successful(Vector.empty) else c.rows(cache.get.h, before)
    if n == 0 then
      // nothing new: the states from the cache; no logits (a prefix's last token has none worth asking)
      fromCache.map(s => (s, Array.empty[Float], if keep then cache else None))
    else
      if consumeCache then cache.foreach(_.consume())
      var h = c.tensor(n, hidden, Array.tabulate(n * hidden)(k => embedding.at(suffix(k / hidden), k % hidden)))
      var states: Future[Vector[Array[Float]]] = Future.successful(Vector.empty)
      val ks = Vector.newBuilder[c.T]; val vs = Vector.newBuilder[c.T]
      var kept: Option[c.T] = None
      for (l, li) <- blocks.zipWithIndex do
        // the attention, if the layer has one (its k and v kept for the cache; an absent one keeps an empty pair)
        val h1 = l.attn match
          case Some(at) =>
            val x = c.rmsNorm(h, at.inNorm, eps)
            val q0 = c.linear(x, at.q); val k0 = c.linear(x, at.k); val v = c.linear(x, at.v); c.release(x)
            val q = c.headNormRope(q0, at.qNorm, heads, headDim, eps, ropeTheta, n0); c.release(q0)
            val k = c.headNormRope(k0, at.kNorm, kvHeads, headDim, eps, ropeTheta, n0); c.release(k0)
            // the keys and values of the whole sequence: the prefix's from the cache, then the new ones
            val (kAll, vAll) = cache.fold((k, v))(cc => { val ka = c.concat(cc.k(li), k); val va = c.concat(cc.v(li), v); c.release(k); c.release(v); (ka, va) })
            if consumeCache then cache.foreach(_.freeLayer(li))
            val a = c.attention(q, kAll, vAll, heads, kvHeads, headDim, n0); c.release(q)
            if keep then { ks += c.cache(kAll); vs += c.cache(vAll) } else { c.release(kAll); c.release(vAll) }
            val o = c.linear(a, at.o); c.release(a)
            val h1 = c.add(h, o); c.release(h); c.release(o); h1
          case None =>
            if consumeCache then cache.foreach(_.freeLayer(li))
            if keep then { ks += c.tensor(0, kvDim, Array.empty); vs += c.tensor(0, kvDim, Array.empty) }
            h
        // the MLP, if the layer has one
        h = l.mlp match
          case Some(m) =>
            val y = c.rmsNorm(h1, m.postNorm, eps)
            val g = c.linear(y, m.gate); val u = c.linear(y, m.up); c.release(y)
            val act = c.swiglu(g, u); c.release(g); c.release(u)
            val d = c.linear(act, m.down); c.release(act)
            val h2 = c.add(h1, d); c.release(h1); c.release(d); h2
          case None => h1
        if li + 1 == layer then
          if after.nonEmpty then states = c.rows(h, after.map(_ - n0))
          if keep then kept = Some(cache.fold(c.slice(h, 0, n))(cc => c.concat(cc.h, h)))
          if consumeCache then cache.foreach(_.freeStates())
      val fin = c.rmsNorm(h, norm, eps); c.release(h)
      val logits =
        if withLogits then head match
          case Some((hd, ids)) =>
            val last = c.slice(fin, n - 1, n); val lg = c.linear(last, hd); c.release(last)
            val read = c.rows(lg, Seq(0)); c.release(lg)
            read.map { rows =>
              val out = Array.fill(vocab)(Float.NegativeInfinity)
              ids.zipWithIndex.foreach((id, k) => out(id) = rows.head(k)); out }
          case None => c.rows(fin, Seq(n - 1)).map(rows => untied.fold(embedding.logits(rows.head))(_(rows.head)))
        else Future.successful(Array.empty[Float])
      c.release(fin)
      val next = if keep then Some(Cache(ids.length, ks.result(), vs.result(), kept.getOrElse(c.tensor(0, hidden, Array.empty)), layer)) else None
      for cached <- fromCache; s <- states; l <- logits yield (cached ++ s, l, next)

  /** OPTIONS WEIGHED IN ONE FORWARD (packed, okay-desk specs/frames.md §6): after a cached prefix (the context but
   * its last token), each option a segment — `last` then the option but its last token — at the positions after the
   * prefix, attending to the prefix and to its own earlier rows only; the rows of all the segments go through every
   * linear together, so the weights are read once for all the options (decoding is bound by reading them). Each
   * option's mean log-probability of its tokens. The cache is read, not changed. */
  def score(cache: Cache, last: Int, options: Vector[Array[Int]])(using ExecutionContext): Future[Vector[Double]] =
    cache.requireLive()
    val ns = options.map(_.length)
    require(ns.forall(_ > 0), "an option of no tokens")
    val starts = ns.scanLeft(0)(_ + _)
    val n = starts.last; val n0 = cache.n
    val ids = options.flatMap(o => last +: o.init).toArray
    var h = c.tensor(n, hidden, Array.tabulate(n * hidden)(k => embedding.at(ids(k / hidden), k % hidden)))
    // a per-segment op over a packed tensor: each segment's rows sliced, the op, the results concatenated back
    def bySegment(x: c.T)(f: (c.T, Int) => c.T): c.T =
      options.indices.map { j =>
        val part = c.slice(x, starts(j), starts(j + 1)); val y = f(part, j); c.release(part); y
      }.reduceLeft { (a, b) => val ab = c.concat(a, b); c.release(a); c.release(b); ab }
    for (l, li) <- blocks.zipWithIndex do
      val h1 = l.attn match
        case Some(at) =>
          val x = c.rmsNorm(h, at.inNorm, eps)
          val q0 = c.linear(x, at.q); val k0 = c.linear(x, at.k); val v = c.linear(x, at.v); c.release(x)
          // each segment from position n0: the rotation as a suffix after the prefix
          val q = bySegment(q0)((p, _) => c.headNormRope(p, at.qNorm, heads, headDim, eps, ropeTheta, n0))
          val k = bySegment(k0)((p, _) => c.headNormRope(p, at.kNorm, kvHeads, headDim, eps, ropeTheta, n0))
          c.release(q0); c.release(k0)
          // each segment attends to the prefix's keys and values, then to its own
          val a = bySegment(q) { (qs, j) =>
            val ks = c.slice(k, starts(j), starts(j + 1)); val vs = c.slice(v, starts(j), starts(j + 1))
            val ka = c.concat(cache.k(li), ks); val va = c.concat(cache.v(li), vs); c.release(ks); c.release(vs)
            val out = c.attention(qs, ka, va, heads, kvHeads, headDim, n0); c.release(ka); c.release(va); out
          }
          c.release(q); c.release(k); c.release(v)
          val o = c.linear(a, at.o); c.release(a)
          val h1 = c.add(h, o); c.release(h); c.release(o); h1
        case None => h
      h = l.mlp match
        case Some(m) =>
          val y = c.rmsNorm(h1, m.postNorm, eps)
          val g = c.linear(y, m.gate); val u = c.linear(y, m.up); c.release(y)
          val act = c.swiglu(g, u); c.release(g); c.release(u)
          val d = c.linear(act, m.down); c.release(act)
          val h2 = c.add(h1, d); c.release(h1); c.release(d); h2
        case None => h1
    val fin = c.rmsNorm(h, norm, eps); c.release(h)
    // the log-probability of each row's next token (the option's own): log-softmax over the head's tokens, a chunk of
    // rows at a time read back (a token the head has not is impossible: −∞)
    val targets = options.flatMap(_.toVector).toArray
    val chunk = 32
    def logProbs(rows: Vector[Array[Float]], from: Int, column: Int => Int): Vector[Double] =
      rows.zipWithIndex.map { (row, i) =>
        val m = row.max; val z = row.iterator.map(x => math.exp((x - m).toDouble)).sum
        val at = column(targets(from + i))
        if at < 0 || row(at).isNegInfinity then Double.NegativeInfinity else (row(at) - m).toDouble - math.log(z)
      }
    val all: Future[Vector[Double]] = head match
      case Some((hd, hids)) =>
        val index = hids.zipWithIndex.toMap
        (0 until n by chunk).foldLeft(Future.successful(Vector.empty[Double])) { (acc, from) =>
          val until = math.min(n, from + chunk)
          val part = c.slice(fin, from, until); val lg = c.linear(part, hd); c.release(part)
          val read = c.rows(lg, 0 until (until - from)); c.release(lg)
          acc.flatMap(got => read.map(rows => got ++ logProbs(rows, from, t => index.getOrElse(t, -1))))
        }
      case None =>
        c.rows(fin, 0 until n).map(rows => logProbs(rows.map(r => untied.fold(embedding.logits(r))(_(r))), 0, identity))
    c.release(fin)
    all.map(lp => options.indices.map(j => lp.slice(starts(j), starts(j + 1)).sum / ns(j)).toVector)
